<?php

		$sq_base_url='';
		$sq_hostname='localhost';
		$sq_dbname='grad_street';
		$sq_dbusername='root';
		$sq_dbpassword='';

?>