 <section class="hero-wrap hero-wrap-2" style="background-image: url(<?php echo base_url('images/bg_1.jpg')?>);">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Course Wise Universities</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo site_url('home')?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Course Wise Universities <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
      <div class="container-fluid px-4">
        <div class="row">

          <?php 

          


            foreach ($uni_course as $key => $val) { 


               if($val['c_name'] ==''){

            echo "No Record Found";
          }

              ?>

             
             
              <div class="col-md-3 course ftco-animate">
                

                  <div class="col-md-12 text-center" style="padding-top: 100px; height:280px;">
                            <div class="img-thumbnail img-w-25" style="padding: 1px; width: 50%;margin: 0 auto;">
                                <img src="<?php echo base_url('imgg/'.$val['logo']);?>" class="img-responsive img-rounded img-loader" width="70%;" alt="">
                            </div>
                            <div><b> <?php echo $val['u_name'].'<br>'.$val['u_address']; ?> </b></div>
                    </div>



                   
                <div class="text pt-4">
                 <!--  <p class="meta d-flex">
                    <span><i class="icon-user mr-2"></i>Mr. Khan</span>
                    <span><i class="icon-table mr-2"></i>10 seats</span>
                    <span><i class="icon-calendar mr-2"></i>4 Years</span>
                  </p> -->
                  <h4><a href="<?php echo site_url('university/apply/'.$val['u_id']);?>"><?php echo $val['c_name']; ?></a></h4>
                  <p><?php echo substr($val['u_details'],0,300) ; ?></p>
                  <p><a href="<?php echo site_url('university/apply/'.$val['u_id']);?>" class="btn btn-primary">Apply now</a></p>
                </div>
              </div>

          
          <?php  }  ?>
        </div><!--row-->
      </div>
    </section>

    <script src="<?php echo base_url('js/jquery.min.js')?>"></script>