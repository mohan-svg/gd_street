<style type="text/css">

/* for from validations*/

form.cmxform label.error, label.error {
    /* remove the next line when you have trouble in IE6 with labels in list */
    color: red;
    font-style: italic
}

input.error { border: 1px dotted red; } /* for from validations*/

.hclass{
  /*background: linear-gradient(45deg, #d1c3c3, transparent);*/
  background: #0d1128;
  padding-left: 10px;

}

.aclass{
  color: #ffffff;
  font-weight: bold;
}

.form-control{
  color: gray!important;
}

.control-label{
  color: #fd5f00;
}

</style>

<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<!-- <section class="hero-wrap hero-wrap-2" style="background-image: url(<?php echo base_url('images/bg_1.jpg')?>);">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Sign Up</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>sign Up <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
 -->
<div class="container">
    <div class="row" style="padding-top:10px;">
        <div class="col-md-8 column-in-center" style="width: 450px; margin: 30px auto; border:1px solid #ccc; background: #f7f7f7;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);">

            <h3 style="text-align:center; padding-bottom:5px;padding-top:10px">Submit Application for <?php echo $result['u_name'];?></h3>
            <form class="cmxform" id="myForm" method="post" accept-charset="utf-8" class="form-horizontal" action="<?php echo site_url('university/single_file');?>" enctype="multipart/form-data">
                <div style="display:none;"></div>

                	<?php if($this->session->flashdata('message')){?>
                                        <!-- <div class="col-sm-3 text-center"> -->
                                            <div id="hides" class="col-sm-12">

                                            <?php echo $this->session->flashdata('message');?>
                                            </div>
                                        <!-- </div> -->

                                        <?php  }   ?>

                  <div class="panel-group" id="accordion" style="padding-bottom: 10px;">
                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h4 class="panel-title hclass">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse10" class="aclass">Course Details &nbsp;&nbsp;&nbsp;&nbsp; >>></a> 
                          </h4>
                        </div>
                        <div id="collapse10" class="panel-collapse in">
                          <div class="panel-body" style="padding-top: 15px;">
                            <input type="hidden" name="uname" class="form-control" value="<?php echo $result['u_name'];?>">
                            <input type="hidden" name="uid" class="form-control" value="<?php echo $result['u_id'];?>">
                           <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Degree Type:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="degreeType" class="form-control" placeholder="e.g. Master of Science"></div> 
                                </div>
                              </div>

                           <div class="form-group row col-lg-12">
                                <label class="col-md-3 col-lg-12 control-label">Course Preference 1:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="course1" class="form-control" placeholder="e.g. Electrical Engg."></div> 
                                </div>
                              </div>
                              <div class="form-group row col-lg-12">
                                <label class="col-md-3 col-lg-12 control-label">Specialization If any:</label>
                                <div class="col-md-8">
                                  <div class="input text"><input type="text" name="specialization1" class="form-control" placeholder="If any specific Specialization" maxlength="255"></div> 
                                </div>
                            </div>
                            
                              <div class="form-group row col-lg-12">
                              <label class="col-md-3 col-lg-12 control-label">Course Preference 2:</label>
                              <div class="col-md-8">
                              <div class="input text"><input type="text" name="course2" class="form-control" placeholder="e.g. Computer Science "></div> 
                              </div>
                              </div>

                              <div class="form-group row col-lg-12">
                                <label class="col-md-3 col-lg-12 control-label">Specialization If any:</label>
                                <div class="col-md-8">
                                  <div class="input text"><input type="text" name="specialization2" class="form-control" placeholder="If any specific Specialization" maxlength="255"></div> 
                                </div>
                            </div>
                           
                              <div class="form-group row col-lg-12">
                                <label class="col-md-3 col-lg-12 control-label">Term:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="term" class="form-control" placeholder="e.g. Spring 2020"></div> 
                                </div>
                              </div>

                            </div><!--panel-body-->
                        </div><!--panel-collapse-->
                      </div><!--panel panel-default-->

                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h4 class="panel-title hclass">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1" class="aclass">Personal Details &nbsp;&nbsp;&nbsp;&nbsp; >>></a> 
                          </h4>
                        </div>
                        <div id="collapse1" class="panel-collapse collapse">
                          <div class="panel-body" style="padding-top: 15px;">
                            <input type="hidden" name="uname" class="form-control" value="<?php echo $result['u_name'];?>">
                            <input type="hidden" name="uid" class="form-control" value="<?php echo $result['u_id'];?>">
                           <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">First Name:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="fname" class="form-control" value="<?php echo $students['stud_fname'];?>"></div> 
                                </div>
                              </div>
                            
                              <div class="form-group row col-lg-12">
                              <label class="col-md-3 control-label">Last Name:</label>
                              <div class="col-md-8">
                              <div class="input text"><input type="text" name="lname" class="form-control" value="<?php echo $students['stud_lname'];?>"></div> 
                              </div>
                              </div>

                              <div class="form-group row col-lg-12">
                                  <label class="col-sm-3 control-label column-in-center">Mobile No:</label>
                                  <div class="col-md-9">
                                  <div class="row" style="padding: 0 1rem;">
                                  <div class="col-md-1" style="padding:0;">
                                  <label class="control-label">+91</label>
                                  
                                  </div>
                                  <div class="col-md-8">
                                      <div class="input tel"><input type="tel" name="mobile" class="form-control" value="<?php echo $students['mobile1'];?>" maxlength="10" id="phone"></div> 
                                  </div>
                                  </div>
                                  </div>
                              </div>
                              <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Email:</label>
                                <div class="col-md-8">
                                  <div class="input text"><input type="text" name="email" class="form-control" placeholder="enter email" maxlength="255" value="<?php echo $students['email'];?>"></div> 
                                </div>
                            </div>
                           
                              <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Mailing Address:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="address" class="form-control" value="<?php echo $students['stud_mail_address'];?>"></div> 
                                </div>
                              </div>

                              <div class="form-group row col-lg-12">
                                  <label class="col-md-3 control-label">City:</label>
                                  <div class="col-md-9">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i id="account-settings-city-name-search-icon" class="fa fa-map-marker"></i></span>
                                          <div class="input text"><input type="text" name="city" class="form-control ui-autocomplete-input" autocomplete="off" value="<?php echo $students['city'];?>"></div> 
                                      </div>
                                  </div>
                              </div>

                              <div class="form-group row col-lg-12" style="padding-bottom: 10px;">
                                  <label class="col-md-3 control-label">Zip code:</label>
                                  <div class="col-md-9">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i id="account-settings-city-name-search-icon" class="fa fa-map-marker"></i></span>
                                          <div class="input text"><input type="text" name="zipcode" class="form-control ui-autocomplete-input" autocomplete="off" value="<?php echo $students['zipcode'];?>"></div> 
                                      </div>
                                  </div>
                              </div>

                          </div><!--panel-body-->
                        </div><!--panel-collapse-->
                      </div><!--panel panel-default-->    
                      
                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h4 class="panel-title hclass">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2" class="aclass">Test Details &nbsp;&nbsp;&nbsp;&nbsp; >>></a>
                          </h4>
                        </div>
                        <div id="collapse2" class="panel-collapse collapse">
                          <div class="panel-body" style="padding-top: 15px;">

                            <label style="font-weight: bold; font-style: italic;"> GRE Details:</label>
                            
                             <div class="form-group">
                                
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">GRE Taken:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-3" style="padding:0;">
                                    <select name="greQues" class="form-control valid" id="gre" style="padding: .3em;height: 40px;"><option value="yes" <?php if($students['gre']=='yes'){?>selected="selected" <?php }?> >Yes</option>
                                      <option value="no" <?php if($students['gre']=='no'){?>selected="selected" <?php }?>>No</option>
                                    </select> 
                                    </div>
                                   <!--  </div> -->
                                  </div>
                                  <div style="clear: both;"></div>
                                
                              </div><!--form-group-->

                            <div class="gre">
                              <label class="form-group"> <div class="col-md-6 col-lg-12" style="color: #fd5f00;">GRE Score:</div></label>
                                <div class="form-group col-md-12">
                                <!-- <label class="col-md-3 control-label">College Name:</label> -->
                                    <div class="col-md-3" style="float: left;">
                                      <label>Total Score: </label>
                                    <input type="text" name="greTotal" class="form-control" value="<?php echo $students['gre_total'];?>" maxlength="255">
                                    </div>
                                    <div class="col-md-3" style="float: left;">
                                      <label>Quants Score: </label>
                                    <input type="text" name="greQuants" class="form-control" value="<?php echo $students['gre_quants'];?>" maxlength="255">
                                    </div>
                                    <div class="col-md-3" style="float: left;">
                                      <label>Verbal Score: </label>
                                    <input type="text" name="greVerbal" class="form-control" value="<?php echo $students['gre_verbal'];?>" maxlength="255">
                                    </div>
                                    <div style="clear: both;"></div>
                              </div>
                            </div><!--class gre-->

                              <div class="form-group">
                                
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">IELTS/TOEFL Taken:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-3" style="padding:0;">
                                    <select name="ieltstoeflQues" class="form-control valid" id="ielts_toefl" style="padding: .3em;height: 40px;"><option value="yes" <?php if($students['ielts_toefl']=='yes'){?>selected="selected" <?php }?> >Yes</option>
                                      <option value="no" <?php if($students['ielts_toefl']=='no'){?>selected="selected" <?php }?>>No</option>
                                    </select> 
                                    </div>
                                   <!--  </div> -->
                                  </div>
                                  <div style="clear: both;"></div>
                                
                              </div>
                            <div class="ielts_toefl">
                              <div class="form-group row col-lg-12" style="padding-bottom: 10px;">
                                <label class="col-md-3 control-label">TOEFL/IELTS Score:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="toefl_ielts" class="form-control"  maxlength="255" value="<?php echo $students['ielts_toefl_score'];?>"></div> 
                                </div>
                              </div>
                            </div><!--ielts_toefl-->
                              
                          </div><!--panel-body-->
                        </div><!--collapse-->
                      </div><!--panel panel-default-->  


                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h4 class="panel-title hclass">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse3" class="aclass">Academic Details &nbsp;&nbsp;&nbsp;&nbsp; >>><span class="glyphicon glyphicon-align-justify"></span></a>
                          </h4>
                        </div>
                        <div id="collapse3" class="panel-collapse collapse">
                          <div class="panel-body" style="padding-top: 15px;">

                            <label style="font-weight: bold; font-style: italic;"> Under Graduate Details:</label>
                            
                             <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">College Name:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="ugCollege" class="form-control" value="<?php echo $students['ug_college'];?>"></div> 
                                </div>
                              </div> 
                             <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Course:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="ugCourse" class="form-control" value="<?php echo $students['ug_course'];?>"></div> 
                                </div>
                              </div>

                            <div class="form-group row col-lg-12">
                                  <label class="col-md-3 control-label">GPA:</label>
                                  <div class="col-md-9">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i id="account-settings-city-name-search-icon" class="fa fa-map-marker"></i></span>
                                          <div class="input text"><input type="text" name="ugGpa" class="form-control ui-autocomplete-input" autocomplete="off" value="<?php echo $students['ug_gpa'];?>"></div> 
                                      </div>
                                  </div>
                              </div><!--GPA-->

                              <div class="form-group row col-lg-12">
                                  <label class="col-md-3 control-label">Passing Year:</label>
                                  <div class="col-md-9">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i id="account-settings-city-name-search-icon" class="fa fa-map-marker"></i></span>
                                          <div class="input text"><input type="text" name="ugPy" class="form-control ui-autocomplete-input" autocomplete="off" value="<?php echo $students['ug_passing_year'];?>"></div> 
                                      </div>
                                  </div>
                              </div><!--GPA-->
                              <label style="font-weight: bold; font-style: italic;"> Post Graduate Details:</label>

                              <div class="form-group row col-lg-12">
                                <!-- <div class="col-md-12">
                                 -->  <div class="col-sm-6 control-label" style="float: left;">Post Graduate Appeared:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-3" style="padding:0;">
                                    <select name="pgQues" class="form-control valid" style="padding: .3em;height: 40px;" id="post-grad"><option value="yes" <?php if($students['work_exp']=='yes'){?>selected="selected" <?php }  ?> >Yes</option>
                                      <option value="no" <?php if($students['work_exp']=='no'){?>selected="selected" <?php }?>>No</option>
                                    </select> 
                                    </div>
                                   <!--  </div> -->
                                  </div>
                                  <div style="clear: both;"></div>
                                <!-- </div> --><!--col-md-12-->
                              </div><!--form-group-->
                  <div class="post-grad">
                                <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">College Name:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="pgCollege" class="form-control" maxlength="255" value="<?php echo $students['pg_college'];?>"></div> 
                                </div>
                              </div>
                             <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Course:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="pgCourse" class="form-control" maxlength="255" value="<?php echo $students['pg_course'];?>"></div> 
                                </div>
                              </div>

                            <div class="form-group row col-lg-12">
                                  <label class="col-md-3 control-label">GPA:</label>
                                  <div class="col-md-9">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i id="account-settings-city-name-search-icon" class="fa fa-map-marker"></i></span>
                                          <div class="input text"><input type="text" name="pgGpa" class="form-control ui-autocomplete-input" autocomplete="off" id="account" value="<?php echo $students['pg_gpa'];?>"></div> 
                                      </div>
                                  </div>
                              </div><!--GPA-->

                              <div class="form-group row col-lg-12" style="padding-bottom: 10px;">
                                  <label class="col-md-3 control-label">Passing Year:</label>
                                  <div class="col-md-9">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i id="account-settings-city-name-search-icon" class="fa fa-map-marker"></i></span>
                                          <div class="input text"><input type="text" name="pgPy" class="form-control ui-autocomplete-input" autocomplete="off" id="account" value="<?php echo $students['pg_passing_year'];?>"></div> 
                                      </div>
                                  </div>
                              </div><!--passing year-->
                      </div><!--class="post-grad"-->

                          </div><!--panel-body-->
                        </div>
                      </div><!--panel panel-default-->  



                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h4 class="panel-title hclass">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse4" class="aclass">Work Experience &nbsp;&nbsp;&nbsp;&nbsp; >>></a>
                          </h4>
                        </div>
                        <div id="collapse4" class="panel-collapse collapse">
                          <div class="panel-body" style="padding-top: 15px;">
                              <div class="form-group">
                                <!-- <div class="col-md-12"> -->
                                  <div class="col-sm-6 control-label" style="float: left;">Do You Have Work Experience:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-3" style="padding:0;">
                                    <select name="weQues" class="form-control valid" style="padding: .3em;height: 40px;" id="work-exp"><option value="yes" <?php if($students['work_exp']=='yes'){?>selected="selected" <?php }?> >Yes</option>
                                      <option value="no" <?php if($students['work_exp']=='no'){?>selected="selected" <?php }?>>No</option>
                                    </select> 
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                <!-- </div> -->
                              </div> <!--form group-->
                        <div class="work-exp"><!--for wrapping purpose-->
                              <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Company Name:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="company" class="form-control" value="<?php echo $students['work_org'];?>" maxlength="255"></div> 
                                </div>
                              </div>
                             

                            <div class="form-group row col-lg-12">
                                <label class="col-md-3 control-label">Position/Profile:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="position" class="form-control" value="<?php echo $students['stud_position'];?>" maxlength="255" id="email"></div> 
                                </div>
                              </div>

                              <div class="form-group row col-lg-12" style="padding-bottom: 10px;">
                                <label class="col-md-3 control-label">Tenure:</label>
                                <div class="col-md-8">
                                <div class="input text"><input type="text" name="tenure" class="form-control" value="<?php echo $students['work_duration'];?>" maxlength="255"></div> 
                                </div>
                              </div>

                        </div><!--for wrapping purpose-->

                          </div><!--panel-body-->
                        </div>
                      </div><!--panel panel-default-->  

                      <div class="panel panel-default">
                        <div class="panel-heading">
                          <h4 class="panel-title hclass">
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse5" class="aclass">Upload Documents &nbsp;&nbsp;&nbsp;&nbsp; >>></a>
                          </h4>
                        </div>
                        <div id="collapse5" class="panel-collapse">
                          <div class="panel-body" style="padding-top: 15px;">
                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Passport:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc1" id="file_1" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->
                        <div class="gre">
                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">GRE Scorecard:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc2" id="file_2" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->
                          </div>
                          <div class="ielts_toefl">
                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">IELTS/TOEFL Scorecard:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc3" id="file_3" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->
                           </div>
                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">3 Letter of Recommendations:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc4" id="file_4" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">SOP:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc5" id="file_5" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Resume:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc6" id="file_6" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Under Graduate Transcript:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc7" id="file_7" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Under Graduate Degree /Provisional Degree:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc8" id="file_8" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Under Graduate Marksheets:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc9" id="file_9" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->
                          <div class="post-grad">
                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Graduate Transcript/ Diploma Transcript:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc10" id="file_10" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Graduate Degree /Provisional Degree:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc11" id="file_11" required="required" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->

                              <div class="form-group">
                                <div class="col-md-12">
                                  <div class="col-sm-6 control-label column-in-center" style="float: left;">Graduate/ Diploma Marksheets:</div>
                                  <div class="col-md-6" style="float: right;">
                                    <!-- <div class="row" style="padding: 0 1rem;"> -->
                                    <div class="col-md-6" style="padding:0;">
                                      <input type="file" name="doc12" id="file_12" required="required" style="width: 100%" />
                                    </div>
                                   <!--  </div> --> 
                                  </div>
                                  <div style="clear: both;"></div>
                                </div>
                              </div> <!--form group-->
                          </div> <!--class="post-grad"-->
                                                        
                          </div><!--panel-body-->
                        </div>
                      </div><!--panel panel-default-->  

                    </div> <!--panel-group-->
<hr>


                <div class="text-center">
                    <div class="form-group">
                          <input type="submit" value="Submit Application" style="border-radius: 0px; background-color: green!important; border-color: #ffffff;" class="btn btn-primary">
                    </div>
                </div>



            </form>

        </div>
    </div>
</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>
<script src="<?php echo base_url('js/dist/jquery.validate.js'); ?>"></script>

<script type="text/javascript">
$(document).ready(function(){
    $("#work-exp").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue == 'yes'){
                // $(".box").not("." + optionValue).hide();
                $(".work-exp").show();
                $(".company").required();
                $(".position").required();
                $(".tenure").required();

            } else{
                $(".work-exp").hide();
            }
        });
    }).change();

    $("#post-grad").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue == 'yes'){
                // $(".box").not("." + optionValue).hide();
                $(".post-grad").show();
            } else{
                $(".post-grad").hide();
            }
        });
    }).change();

    $("#gre").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue == 'yes'){
                // $(".box").not("." + optionValue).hide();
                $(".gre").show();
            } else{
                $(".gre").hide();
            }
        });
    }).change();

    $("#ielts_toefl").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue == 'yes'){
                // $(".box").not("." + optionValue).hide();
                $(".ielts_toefl").show();
            } else{
                $(".ielts_toefl").hide();
            }
        });
    }).change();
});
</script>

<script>
  
    $().ready(function() {
    
        // validate signup form on keyup and submit
        $("#myForm").validate({
            rules: {

              degreeType:"required",

                course1:"required",
                course2:"required",

                term:"required",

               email: {
                    required: true,
                    email: true
                  }, 
                                         
                
                fname: {
                  required: true
                },
                lname: {
                  required: true
                },
                          
                mobile: {
                  required: true,
                  minlength: 10,
                  maxlength:10
                },
                gender: {
                  required: true
                },

                address:"required",

                city:"required",

                zipcode: {
                  required: true,
                  minlength: 6,
                  maxlength:6
                },

                greTotal: {
                            required: true,
                            minlength: 3,
                          maxlength:3,
                          }, 
                                                 
                        greQuants: {
                          required: true,
                          minlength: 3,
                          maxlength:3
                        },
                        greVerbal: {
                          required: true,
                          minlength: 3,
                          maxlength:3
                        },

              ielts:"required",
              ugCollege:"required",
              ugCourse:"required",
              ugGpa:"required",
              ugPy:"required",
              pgCollege:"required",
              pgCourse:"required",
              pgGpa:"required",
              pgPy:"required",
              company:"required",
              position:"required",
              tenure:"required",

              //documents

              doc1:"required",
              doc2:"required",
              doc3:"required",
              doc4:"required",
              doc5:"required",
              doc6:"required",
              doc7:"required",
              doc8:"required",
              doc9:"required",
              doc10:"required",
              doc11:"required",
              doc12:"required",
                                            
            },
            messages: {

                degreeType:"Please Enter Degree Type for foreign education",

                course1:"Provide 1st Preference Course",
                course2:"Provide 1st Preference Course",

                term:"Enter the Term of Application",

                email: "Please enter a valid email address",
                
                fname: "Enter First name",
                lname: "Enter Last name",
                mobile: {
                  required: "Enter Mobile No.",
                  minlength: "Provide Valid Mobile No.",
                  maxlength:"Provide Valid Mobile No.",
                },
                gender: "Please Select Gender",
                address: "Please Provide your mailing address",
                city: "Please Enter City",
                zipcode: {
                  required: "Enter Zipcode",
                  minlength: "Provide Valid Zipcode",
                  maxlength:"Provide Valid Zipcode",
                },

                 greTotal: {
                        required: "Enter GRE Total-Marks",
                        minlength: "Enter Valid GRE Marks",
                        maxlength: "Enter Valid GRE Marks"
                      },
                      greQuants: {
                        required: "Enter GRE Quants-Marks",
                        minlength: "Enter Valid GRE Marks",
                        maxlength: "Enter Valid GRE Marks"
                      },
                      greVerbal: {
                        required: "Enter GRE Verbal-Marks",
                        minlength: "Enter Valid GRE Marks",
                        maxlength: "Enter Valid GRE Marks"
                      },
              ielts:"Enter IELTS/TOEFL Marks",
              ugCollege:"Enter UG-College",
              ugCourse:"Enter UG-Course",
              ugGpa:"Enter UG-GPA",
              ugPy:"Enter UG-Passing Year",
              pgCollege:"Enter PG-College",
              pgCourse:"Enter PG-Course",
              pgGpa:"Enter PG-GPA",
              pgPy:"Enter PG Passing Year",
              company:"Enter Company Name",
              position:"Enter your Designation",
              tenure:"Enter your working Tenure",

              //documents
              
              doc1:"Upload Your Passport",
              doc2:"Upload Your GRE Scorecard",
              doc3:"Upload Your IELTS/TOEFL Scorecard",
              doc4:"Upload Your 3-Letter of Recommendations combined in one pdf",
              doc5:"Upload Your SOP",
              doc6:"Upload Your Resume",
              doc7:"Upload Your Under Graduate Transcript",
              doc8:"Upload Your Under Graduate Degree /Provisional Degree",
              doc9:"Upload Your Under Graduate Marksheets with back pages",
              doc10:"Upload Your Graduate Transcript/ Diploma Transcript",
              doc11:"Upload Your Graduate Degree /Provisional Degree",
              doc12:"Upload Your Graduate/ Diploma Marksheets",
                
            }//messages
        });

           
    });
</script>