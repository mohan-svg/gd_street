

  <!-- JavaScript Libraries -->
  <!-- <script src="<?php echo base_url('assets2/lib/jquery/jquery.min.js')?>"></script> -->
  <script src="<?php echo base_url('assets2/lib/jquery/jquery-migrate.min.js')?>"></script>
  <script src="<?php echo base_url('assets2/lib/bootstrap/js/bootstrap.bundle.min.js')?>"></script>
  <script src="<?php echo base_url('assets2/lib/easing/easing.min.js')?>"></script>
  <script src="<?php echo base_url('assets2/lib/wow/wow.min.js')?>"></script>
  <script src="<?php echo base_url('assets2/lib/superfish/hoverIntent.js')?>"></script>
  <script src="<?php echo base_url('assets2/lib/superfish/superfish.min.js')?>"></script>
  <script src="<?php echo base_url('assets2/lib/magnific-popup/magnific-popup.min.js')?>"></script>

  <!-- <script src="<?php echo base_url('assets/bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>"></script> -->

<!-- <script src="<?php echo base_url('assets/bower_components/datatables.net/js/jquery.dataTables.min.js'); ?>"></script>

<script src="<?php echo base_url('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js'); ?>"></script> -->

  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url('assets2/contactform/contactform.js')?>"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url('assets2/js/main.js')?>"></script>

</body>
</html>

