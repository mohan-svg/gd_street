
		<section class="content">
			<div class="container-fluid">
				<div class="block-header">
					<h2>Form</h2>
				</div>
				<div class="row clearfix">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="card">
							<div class="header">
								<h2>
									Add News
								</h2>
								
							</div>
							<div class="body">
								<form class="form-horizontal">
									<div class="row clearfix">
										<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
											<label for="apfee">News Image:</label>
										</div>
										<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
											<div class="form-group">
												<div class="form-line">
													<input type="file" class="form-control">
													
												</div>
											</div>
										</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="sopfee">News Title:</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
                                        <div class="form-group">
											<div class="form-line">
												<input type="text" class="form-control">
												
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="sopfee">Content:</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
                                        <div class="form-group">
											<div class="form-line">
												<input type="text" class="form-control">
												
											</div>
										</div>
									</div>
								</div>
								<div class="row clearfix">
									<div class="col-lg-2 col-md-2 col-sm-4 col-xs-5 form-control-label">
                                        <label for="sopfee">Posting Date:</label>
									</div>
									<div class="col-lg-8 col-md-8 col-sm-8 col-xs-7">
                                        <div class="form-group">
											<div class="form-line">
												<input type="date" class="form-control">
												
											</div>
										</div>
									</div>
								</div>
								
                                <div class="row clearfix">
                                    <div class="col-lg-offset-2 col-md-offset-2 col-sm-offset-4 col-xs-offset-5">
                                        <button type="button" class="btn btn-primary m-t-15 waves-effect">Add</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			
			
		</div>
	</section>
	