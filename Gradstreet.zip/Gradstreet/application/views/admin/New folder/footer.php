

<!-- Jquery Core Js -->
    <script src="<?php echo base_url('admin_panel/plugins/jquery/jquery.min.js'); ?>"></script>

    <!-- Bootstrap Core Js -->
    <script src="<?php echo base_url('admin_panel/plugins/bootstrap/js/bootstrap.js'); ?>"></script>

    <!-- Select Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/bootstrap-select/js/bootstrap-select.js'); ?>"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/jquery-slimscroll/jquery.slimscroll.js'); ?>"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/node-waves/waves.js'); ?>"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/jquery-countto/jquery.countTo.js'); ?>"></script>

    <!-- Morris Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/raphael/raphael.min.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/morrisjs/morris.js'); ?>"></script>

    <!-- ChartJs -->
    <script src="<?php echo base_url('admin_panel/plugins/chartjs/Chart.bundle.js'); ?>"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/flot-charts/jquery.flot.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/flot-charts/jquery.flot.resize.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/flot-charts/jquery.flot.pie.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/flot-charts/jquery.flot.categories.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/flot-charts/jquery.flot.time.js'); ?>"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/jquery-sparkline/jquery.sparkline.js'); ?>"></script>

    
<!-- Js For form element -->

     <!-- Autosize Plugin Js -->
     <script src="<?php echo base_url('admin_panel/plugins/autosize/autosize.js'); ?>"></script>

    <!-- Moment Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/momentjs/moment.js'); ?>"></script>

    <!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js'); ?>"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>"></script>

    <!-- #Js for form element -->

     <!-- Jquery DataTable Plugin Js -->
     <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/buttons.flash.min.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/jszip.min.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/pdfmake.min.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/vfs_fonts.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/buttons.html5.min.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/plugins/jquery-datatable/extensions/export/buttons.print.min.js'); ?>"></script>

    <!-- SweetAlert Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/sweetalert/sweetalert.min.js'); ?>"></script>

    <!-- Bootstrap Notify Plugin Js -->
    <script src="<?php echo base_url('admin_panel/plugins/bootstrap-notify/bootstrap-notify.js'); ?>"></script>

    
    <!-- Custom Js -->
    <script src="<?php echo base_url('admin_panel/js/admin.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/js/pages/index.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/js/pages/forms/basic-form-elements.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/js/pages/tables/jquery-datatable.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/js/pages/ui/dialogs.js'); ?>"></script>
    <script src="<?php echo base_url('admin_panel/js/pages/examples/profile.js'); ?>"></script>
    <!-- Demo Js -->
    <script src="<?php echo base_url('admin_panel/js/demo.js'); ?>"></script>


</body>

</html>
