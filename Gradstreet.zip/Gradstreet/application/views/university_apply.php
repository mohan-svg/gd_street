
<!-- JQuery DataTable Css -->
 <script src="<?php echo base_url('assets2/dataTable/jquery.dataTables.min.js')?>"></script>

<style>
    h4>ol>li {
        padding-bottom:8px;
    }

    .label-sm {
        font-size: .7em;
        padding: .2em .5em;
        line-height: 1.5em;
    }


#example_wrapper{
    width: 100%;
}

    @media(max-width: 978px){

      .tc{
        text-align: center;
      }

      .ts{

        font-size: 21px;
      }

      .tj{
        text-align: justify; 
        font-size:17px;
      }
    }


    th{
        text-align: center;
        border-bottom: 1px solid gray;
        color: #fd5f00;
    }

    thead{
        background-color: #d5dbdb;
    }
    td{
        padding-top: 10px;
    }
tr{
    border-bottom: 1px solid  #b2babb; 
}

    


</style>

   <section id="login">
        
        <div class="container">
            <div class="intro-text">
              <h3>Apply through GradStreet for fast and smooth process</h3>
              <p>MS in US University Just One Step to go</p>
              <a href="<?php echo site_url('university')?>" class="btn-get-started">Apply Now</a>      

            </div> 
        </div>
    </section>


    <section id="more-features" class="section-bg">

    <!--For Desktop -->
    <div class="container visible-md visible-lg" style="padding-top:20px;">
        <div class="row application" style="margin-left:15px;margin-right:15px;">
            <h1 class="tc ts">
              <strong >Apply to Universities via Grad Street</strong><br>
            </h1>

                <h3 class="tj" style="padding-bottom: 20px;">Save over <strong>$100</strong> on University application fee /Application processing fees / SOP evaluation<br><small>(only for selected universities as listed below)</small>
            </h3>
                <br /><br /><br />




              <?php
            if(count($result)==0){
              ?>
                
                <div class="row row-alt-striped" style="margin: 0; padding: .5em; border-radius: 5px;">
                        <div class="col-sm-12 col-md-5" style="padding: 1em; margin: 0;">

                          <h2>No Record Found</h2>

                        </div>
                </div><!--row row-alt-striped-->

              <?php

                      } //if result ==0

            if($this->session->userdata('logged_in')=='true'){ 

                $this->db->where('stud_id',$this->session->userdata('id'));
                $query = $this->db->get('student_details')->row_array();

                $univ_arr = explode (",", $query['submited_university']);  
             //   print_r($univ_arr); 

               
                ?>


            <table id="example" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>University</th>
                    <th>Application fees</th>                
                    <th>Application Processing Fees</th>
                    <th>Savings</th>
                </tr>
            </thead>
            <tbody>

            <?php foreach($result as $key => $val){       ?>

                <tr>
                    <td >
                        <div class="row">
                            <div class="col-md-4"><img src="<?php echo base_url('universityImages/'.$val['logo']) ?>" width="90px"></div>
                            <div  class="col-md-8" style="padding-top: 15px;"><b>  <?php echo $val['university_name'];?></b>  <br/>
                            <?php echo $val['location'];?> </div>  
                        </div>
                    </td>

                    <td class="text-center">
                        <?php if($val['app_fees_free']=='yes'){ 
                            $app_fee = $val['b_univ_fees']; ?>
                                <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</strike>

                                         &nbsp; <span style="font-weight: bold; font-size: 1.5em;">
                                                <span class="text-success" style="font-weight: 100;">Free</span> 
                                        </span>
                                    <?php } else{ ?>
                                                <span style="font-weight: bold; font-size: 1.5em;">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</span>
                                    <?php 
                                                $app_fee = 0;
                             } ?>
                                
                        <br /> Application Fee
                    </td>
                                   
                    <td class="text-center">
                        <?php if($val['app_process_free']=='yes'){ 
                                            $process_fees = $val['b_app_process_fees'];
                                        ?>
                                            <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_app_process_fees'];?>&nbsp;</strike>&nbsp;
                                            <span style="font-weight: bold; font-size: 1.5em;">
                                                    <span class="text-success" style="font-weight: 100;">Free</span> 
                                            </span>

                                    <?php } else{ ?>
                                                <span style="font-weight: bold; font-size: 1.5em;">$<?php echo $val['b_app_process_fees'];?> </span>
                                    <?php   $process_fees = 0;

                                     } ?>    

                                 <br />    Application Processing Fee
                    </td>

                    <?php 

                    $counter = 0;

                   foreach($univ_arr as $key=>$univ){ 

                      if($univ_arr[$key]==$val['u_name_id']){ 

                            $counter++;

                       } //if()
                    }//foreach()

                   if($counter>0){ 

                    ?> 
                    		<td >
                           
                                <br>
                                <a href="#" class="btn btn-block btn-warning text-uppercase" style="border-radius: 0px !important;"> Applied
                                &nbsp;
                                <i class="fa fa-angle-right"></i>
                                </a>
                                <div class="text-center text-success" style="font-size: 1.05em; padding: .2em 0; ">
                                  (You saved $<?php echo ($process_fees+$app_fee); ?>)
                                </div>
                         

                    		</td>

                     <?php } else{   
         //checking for counter incremented or not
                ?>

    	                <td >
    	                       
    	                            <br>
    	                            <a href="<?php echo site_url('apply_to_univesity/'.'a1h9'.$val['u_name_id']);?>" class="btn btn-block btn-success text-uppercase" style="border-radius: 0px !important;">
    	                            Apply
    	                            &nbsp;
    	                            <i class="fa fa-angle-right"></i>
    	                            </a>
    	                            <div class="text-center text-success" style="font-size: 1.05em; padding: .2em 0; ">
    	                              (You save $<?php echo ($process_fees+$app_fee); ?>)
    	                            </div>
    	                     

    	                </td>

                     <?php } //else counter ?>
                    
                </tr>
               
            <?php } //foreach()?>

          
        </table>


    <?php } else{
    //if(logged_in==true)

     ?>

   
            <table id="example" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th>University</th>
                        <th>Application fees</th>                
                        <th>Application Processing Fees</th>
                        <th>Savings</th>
                    </tr>
                </thead>
                <tbody>

                <?php foreach($result as $key => $val){       ?>

                    <tr>
                        <td>
                           <div class="row">
                                <div class="col-md-4"><img src="<?php echo base_url('universityImages/'.$val['logo']) ?>" width="90px"></div>
                                <div  class="col-md-8" style="padding-top: 15px;"><b>  <?php echo $val['university_name'];?></b>  <br/>
                                <?php echo $val['location'];?> </div>  
                            </div>
                                    
                        </td>

                        <td class="text-center">
                            
                                        <?php if($val['app_fees_free']=='yes'){ 

                                            $app_fee = $val['b_univ_fees']; ?>
                                             <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</strike>

                                             &nbsp; <span style="font-weight: bold; font-size: 1.5em;">
                                                    <span class="text-success" style="font-weight: 100;">Free</span> 
                                            </span>
                                        <?php } else{ ?>
                                                    <span style="font-weight: bold; font-size: 1.5em;">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</span>
                                        <?php 
                                                    $app_fee = 0;

                                    } ?>
                                    
                                    
                                   
                                       <br /> Application Fee
                               

                        </td>

                        <td class="text-center">

                                    
                                        <?php if($val['app_process_free']=='yes'){ 
                                                $process_fees = $val['b_app_process_fees'];
                                            ?>
                                                <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_app_process_fees'];?>&nbsp;</strike>&nbsp;
                                                <span style="font-weight: bold; font-size: 1.5em;">
                                                        <span class="text-success" style="font-weight: 100;">Free</span> 
                                                </span>

                                        <?php } else{ ?>
                                                    <span style="font-weight: bold; font-size: 1.5em;">$<?php echo $val['b_app_process_fees'];?> </span>
                                        <?php   $process_fees = 0;

                                         } ?>    
                                  
                                     <br />    Application Processing Fee
                               
                        </td>

                        <td >
                               
                                    <br>
                                    <a href="<?php echo site_url('apply_to_univesity/'.'a1h9'.$val['u_name_id']);?>" class="btn btn-block btn-success text-uppercase" style="border-radius: 0px !important;">
                                    Apply
                                    &nbsp;
                                    <i class="fa fa-angle-right"></i>
                                    </a>
                                    <div class="text-center text-success" style="font-size: 1.05em; padding: .2em 0; ">
                                      (You save $<?php echo ($process_fees+$app_fee); ?>)
                                    </div>
                             

                        </td>
                        
                    </tr>
                   
                <?php } //foreach ?>

            </table>

         <?php   } //else of if (loggedin == true)   ?>
          

    </div><!--row application-->
</div><!---container  for desktop-->


<!---Mobile Version-->
<div class="container visible-sm visible-xs">

         <div class="section-header">
          <h3 class="section-title">Apply to Universities via Grad Street</h3>
          <span class="section-divider"></span>
          <p class="section-description">Save over <strong>$100</strong> on University application fee /Application processing fees / SOP evaluation<br><small>(only for selected universities as listed below)</small></p>
        </div>

        <?php   if(count($result)==0){  ?>

              <div class="col-lg-6">
                <div class="box wow fadeInLeft">               
                  
                  <p class="description">NO Universities Found</p>
                </div>
              </div>    

        <?php    } //if result ==0

            if($this->session->userdata('logged_in')=='true'){ 

                $this->db->where('stud_id',$this->session->userdata('id'));
                $query = $this->db->get('student_details')->row_array();

                $univ_arr = explode (",", $query['submited_university']);  
             //   print_r($univ_arr); 
              ?>  


                <table id="example1" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Universities</th>                            
                        </tr>
                    </thead>
                    <tbody>

                     <div class="row">
                        <?php foreach($result as $key => $val){   ?>

                            <tr>
                                <td>
                            <!-- <div class="col-lg-6"> -->
                                <div class="box wow fadeInLeft">
                                  <div class="icon"><img src="<?php echo base_url('universityImages/'.$val['logo']) ?>" width="60px"></div>
                                  <h4 class="title"><a href=""><?php echo $val['university_name'];?></a></h4>
                                  <h5 class="text-center"><?php echo $val['location'];?></h5>
                                  <p class="description">
                                    <?php if($val['app_fees_free']=='yes'){ 
                                        $app_fee = $val['b_univ_fees']; ?>
                                        <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</strike>

                                                 &nbsp; <span style="font-weight: bold; font-size: 1.5em;">
                                                        <span class="text-success" style="font-weight: 100;">Free</span> 
                                                </span>
                                            <?php } else{ ?>
                                                        <span style="font-weight: bold; font-size: 1.5em;">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</span>
                                            <?php 
                                                        $app_fee = 0;
                                     } ?>
                                
                                <br /> Application Fee<br />

                                <?php if($val['app_process_free']=='yes'){ 
                                            $process_fees = $val['b_app_process_fees'];
                                        ?>
                                            <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_app_process_fees'];?>&nbsp;</strike>&nbsp;
                                            <span style="font-weight: bold; font-size: 1.5em;">
                                                    <span class="text-success" style="font-weight: 100;">Free</span> 
                                            </span>

                                    <?php } else{ ?>
                                                <span style="font-weight: bold; font-size: 1.5em;">$<?php echo $val['b_app_process_fees'];?> </span>
                                    <?php   $process_fees = 0;

                                     } ?>    

                                 <br />    Application Processing Fee<br />

                                 <?php     $counter = 0;

                                   foreach($univ_arr as $key=>$univ){ 

                                      if($univ_arr[$key]==$val['u_name_id']){ 

                                            $counter++;

                                       } //if()
                                    }//foreach()

                                   if($counter>0){    ?> 

                                        <br/>
                                        <a href="#" class="btn btn-block btn-warning text-uppercase" style="border-radius: 0px !important;"> Applied
                                        &nbsp;
                                        <i class="fa fa-angle-right"></i>
                                        </a>
                                        <div class="text-center text-success" style="font-size: 1.05em; padding: .2em 0; ">
                                          (You saved $<?php echo ($process_fees+$app_fee); ?>)
                                        </div>
                                <?php } else{   //checking for counter incremented or not  ?>

                                            <br>
                                            <a href="<?php echo site_url('apply_to_univesity/'.'a1h9'.$val['u_name_id']);?>" class="btn btn-block btn-success text-uppercase" style="border-radius: 0px !important;">
                                            Apply
                                            &nbsp;
                                            <i class="fa fa-angle-right"></i>
                                            </a>
                                            <div class="text-center text-success" style="font-size: 1.05em; padding: .2em 0; ">
                                              (You save $<?php echo ($process_fees+$app_fee); ?>)
                                            </div>
                                    <?php } //else counter ?>
                            </p>


                                </div> <!-- ./box wow fadeInLeft -->
                              <!-- </div> -->

                              </td> 
                          </tr>
                        <?php } //foreach()?>
                     
                         </div>
                </tbody>
            </table>
         <?php } else{ //if(logged_in==true)   ?>

            <!--If NOt Logged In-->

            <table id="example1" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Universities</th>                            
                        </tr>
                    </thead>
                    <tbody>
                        
                    <!-- <div class="row"> -->
                    <?php foreach($result as $key => $val){   ?>
                        <tr>
                            <td>
                             <!-- <div class="col-lg-6"> -->
                                <div class="box wow fadeInLeft">
                                  <div class="icon"><img src="<?php echo base_url('universityImages/'.$val['logo']) ?>" width="60px"></div>
                                  <h4 class="title"><a href=""><?php echo $val['university_name'];?></a></h4>
                                  <h5 class="text-center"><?php echo $val['location'];?></h5>
                                  <p class="description">

                                    <?php if($val['app_fees_free']=='yes'){ 

                                            $app_fee = $val['b_univ_fees']; ?>
                                             <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</strike>

                                             &nbsp; <span style="font-weight: bold; font-size: 1.5em;">
                                                    <span class="text-success" style="font-weight: 100;">Free</span> 
                                            </span>
                                        <?php } else{ ?>
                                                    <span style="font-weight: bold; font-size: 1.5em;">&nbsp;$<?php echo $val['b_univ_fees'];?>&nbsp;</span>
                                        <?php   $app_fee = 0;  } //else ?>
                                   
                                       <br /> Application Fee <br />

                                       <?php if($val['app_process_free']=='yes'){ 
                                                $process_fees = $val['b_app_process_fees'];
                                            ?>
                                                <strike style="text-decoration: line-through; opacity: .8; font-size: 1.2em;" class="text-danger">&nbsp;$<?php echo $val['b_app_process_fees'];?>&nbsp;</strike>&nbsp;
                                                <span style="font-weight: bold; font-size: 1.5em;">
                                                        <span class="text-success" style="font-weight: 100;">Free</span> 
                                                </span>

                                        <?php } else{ ?>
                                                    <span style="font-weight: bold; font-size: 1.5em;">$<?php echo $val['b_app_process_fees'];?> </span>
                                        <?php   $process_fees = 0;

                                         } ?>    
                                  
                                     <br />    Application Processing Fee <br /> 

                                     <br>
                                    <a href="<?php echo site_url('apply_to_univesity/'.'a1h9'.$val['u_name_id']);?>" class="btn btn-block btn-success text-uppercase" style="border-radius: 0px !important;">
                                    Apply
                                    &nbsp;
                                    <i class="fa fa-angle-right"></i>
                                    </a>
                                    <div class="text-center text-success" style="font-size: 1.05em; padding: .2em 0; ">
                                      (You save $<?php echo ($process_fees+$app_fee); ?>)
                                    </div>


                                  </p>
                                </div> <!-- ./box wow fadeInLeft -->
                              <!-- </div>  --> 
                              </td>
                   </tr>
                        <?php } //foreach() ?>
                     
                       <!--  </div> -->
                   
                </tbody>
            </table>

        <?php   } //else of if (loggedin == true)   ?>

</div><!---container  for mobile-->

</section>
 <br/>
 <br/>
 <br/>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>
    
<script type="text/javascript">
        $(document).ready(function() {
            $('#example1').DataTable();
        } );
    </script>
    
    