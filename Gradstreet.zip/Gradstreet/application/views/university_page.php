

<style type="text/css">
    @media screen and (min-width: 769px){
        #univ_logo{
                margin-top: 43px;
        }

        .university_title{
            text-align: left;
            padding: 0px !important;
            font-size: 25px !important;
        }

        .university_location{
            text-align: left;
            color: #fff;
        }

        #exampleModalLongTitle{
            margin-left: 30%;
        }
    }
 @media screen and (max-width: 768px){
        #univ_logo{
                    width: 100px;
                    margin-left: 35%;
        }

    }

.modal.in{z-index:10000!important}
.modal-backdrop.in{z-index:9999!important}

</style>

<section id="login" style="background: linear-gradient(rgba(179, 60, 50, 0.8), rgba(60, 29, 5, 0.8)), url(<?php echo base_url('universityImages/'.$university_images->img1) ?>);">
        
        <div class="container"> 
            <div class="intro-text">             
                <div class="row wow fadeInUp">
                  <div class="box col-md-3" style="text-align: center;">
                    <img src="<?php echo base_url('universityImages/'.$university_images->logo) ?>" alt="" class="img-responsive" id="univ_logo">
                    </div>
                    <div class="box col-md-9">
                        <h3 class="university_title"><?php echo $university_name->university_name ?></h3>
                        <h4 class="university_location" style="color: #fff;"><?php echo $university_name->location ?></h4>
                    </div>
                </div>
              <a href="" class="btn-get-started" data-toggle="modal" data-target="#university_application">Apply Here</a>      
            </div>
        </div>
</section>

<!--==========================
      About Us Section
    ============================-->
    <section id="about" class="section-bg">
      <div class="container-fluid" style="">
        <div class="section-header">
          <h3 class="section-title">About <?php echo $university_name->university_name ?></h3>
          <span class="section-divider"></span>
          <p class="section-description padding_right_left" style="text-align: justify;">
            <?php echo $university_name->description ?>
          </p>
        </div>

        <div class="row" style="margin-left: 0px; margin-right: 0px;">
          <div class="col-lg-6 university-img wow fadeInLeft">
            <img src="<?php echo base_url('universityImages/'.$university_images->main_img) ?>" alt="">
          </div>

          <div class="col-lg-6 content wow fadeInRight">
           
            <ul>
                <li><i class="ion-android-checkmark-circle"></i> Location: <?php echo $university_name->location ?></li>
              <li><i class="ion-android-checkmark-circle"></i> Campuses: <?php echo $university_name->campus ?></li>
              <li><i class="ion-android-checkmark-circle"></i> Tuition Fees: <?php echo $university_name->tuition_fees ?></li>
              <li><i class="ion-android-checkmark-circle"></i> Application Fees: <?php if($benefit->app_fees_free == 'yes'){ ?> <b style=" color:green;">Waiver</b> <?php  }  else { ?> <b style=" color:green;"> <?php echo $benefit->currency_unit.$benefit->b_univ_fees;?> </b><?php } ?></li>            
            </ul> 
            <h4 class="section-title">All Available Courses</h4>
           <select class="form-control" name="course_name" style="padding: .3em;height: 30px;">
               <option value="">--All Courses Here--</option>
                <?php foreach ($course as $key => $value): ?>
                    <option value="<?php echo $value['university_details_id'] ?>"><?php echo $value['course_name'] ?></option>
                <?php endforeach ?>               
           </select>
           <br/>
           <a href="" class="btn btn-success" data-toggle="modal" data-target="#university_application">Apply Here</a>   
          </div>
        </div>

      </div>
    </section><!-- #about -->

<!--==========================
      Gallery Section
    ============================-->
    <section id="gallery">
      <div class="container-fluid">
        <div class="section-header">
          <h3 class="section-title">University Tour</h3>
          <span class="section-divider"></span>          
        </div>

        <div class="row no-gutters">
              <div class="col-lg-3 col-md-6">
                <div class="gallery-item wow fadeInUp">
                  <a href="<?php echo base_url('universityImages/'.$university_images->img5) ?>" class="gallery-popup">
                    <img src="<?php echo base_url('universityImages/'.$university_images->img5) ?>" alt="">
                  </a>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="gallery-item wow fadeInUp">
                  <a href="<?php echo base_url('universityImages/'.$university_images->img2) ?>" class="gallery-popup">
                    <img src="<?php echo base_url('universityImages/'.$university_images->img2) ?>" alt="">
                  </a>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="gallery-item wow fadeInUp">
                  <a href="<?php echo base_url('universityImages/'.$university_images->img3) ?>" class="gallery-popup">
                    <img src="<?php echo base_url('universityImages/'.$university_images->img3) ?>" alt="">
                  </a>
                </div>
              </div>

              <div class="col-lg-3 col-md-6">
                <div class="gallery-item wow fadeInUp">
                  <a href="<?php echo base_url('universityImages/'.$university_images->img4) ?>" class="gallery-popup">
                    <img src="<?php echo base_url('universityImages/'.$university_images->img4) ?>" alt="">
                  </a>
                </div>
              </div>         

        </div><!--..row no-gutters-->

      </div>
    </section><!-- #gallery -->
<br/><br/>

<!-- Modal -->
<div class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Submit Your Application</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="submit_application">
            <input type="hidden" name="university_id" value="<?php echo $university_name->u_name_id ?>">
            <div class="form-group row">
                <label for="staticUniversity" class="col-sm-2 col-form-label">University Name: </label>
                <div class="col-sm-10">
                  <input type="text" readonly class="form-control-plaintext" id="staticUniversity" value="<?php echo $university_name->university_name ?>" name="university_name">
                </div>
              </div>
              <div class="form-group row">
                <label for="inputPassword" class="col-sm-2 col-form-label">Course</label>
                <div class="col-sm-10">
                  <select class="form-control" name="course_name" style="padding: .3em;height: 30px;" required>
                    <option value="">--Select Course--</option>
                        <<?php foreach ($course as $key => $value): ?>
                            <option value="<?php echo $value['university_details_id'] ?>"><?php echo $value['course_name'] ?></option>
                        <?php endforeach ?>               
                   </select>
                </div>
              </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade bd-example-modal-lg" id="university_application" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content" style="background: #fd5f00;
    color: #fff;">
      <div class="modal-header" style="text-align: center;">
        <h3 class="modal-title" id="exampleModalLongTitle" >Submit Your Application</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="submit_application">
            <input type="hidden" name="university_id" value="<?php echo $university_name->u_name_id ?>">
            <div class="form-group row">
                <label for="staticUniversity" class="col-sm-4 col-form-label">University Name: </label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control-plaintext" id="staticUniversity" value="<?php echo $university_name->university_name ?>" name="university_name">
                </div>
              </div>
              <div class="form-group row">
                <label for="inputPassword" class="col-sm-4 col-form-label">Course</label>
                <div class="col-sm-8">
                  <select class="form-control" name="course_name" style="padding: .3em;height: 50px;" required>
                    <option value="">--Select Course--</option>
                        <<?php foreach ($course as $key => $value): ?>
                            <option value="<?php echo $value['university_details_id'] ?>"><?php echo $value['course_name'] ?></option>
                        <?php endforeach ?>               
                   </select>
                </div>
              </div>
              <div class="form-group row">
                <label for="staticUniversity" class="col-sm-4 col-form-label">Application fees: </label>
                <div class="col-sm-8">
                  <input type="text" readonly class="form-control-plaintext" id="staticUniversity" value="<?php echo $university_name->university_name ?>" name="university_name">
                </div>
              </div>

              <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Submit Application</button>
              </div>
        </form>
      </div>
      
    </div>
  </div>
</div>