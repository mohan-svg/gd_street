function validate()
            {
                var firstName = document.getElementById("firstName").value;
                var lastName = document.getElementById("lastName").value;
                var email = document.getElementById("email").value;
                var birthDate = document.getElementById("birthDate").value;
                var mobile = document.getElementById("mobile").value;
                var countobirth = document.getElementById("countobirth").value;
                var countocitizen = document.getElementById("countocitizen").value;
                var addl1 = document.getElementById("addl1").value;
                var citys = document.getElementById("citys").value;

                var countrys = document.getElementById("countrys").value;
                var zipcodes = document.getElementById("zipcodes").value;
                var intakes = document.getElementById("intakes").value;
                var ms_program = document.getElementById("ms_program").value;
                var campuss = document.getElementById("campuss").value;
                
                var passport = document.getElementById("passport").value;
                var gres = document.getElementById("gres").value;
                var english = document.getElementById("english").value;
                var ug_trans = document.getElementById("ug_trans").value;
                var ug_degree = document.getElementById("ug_degree").value;
                var ug_marksheet = document.getElementById("ug_marksheet").value;
                var lors = document.getElementById("lors").value;                
                var sops = document.getElementById("sops").value;
                var resumes = document.getElementById("resumes").value; 
                               
                var ssign = document.getElementById("ssign").value;
                var lors = document.getElementById("lors").value;                
                var sops = document.getElementById("sops").value;
                // var pattern = document.getElementById("pattern").value;
                // var patcheck = new RegExp("^[a-z0-9]");
                if(firstName==="")
                {
                    document.getElementById("fname").innerHTML="Enter Firstname";
                    document.getElementById("fname").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("fname").innerHTML="";
                   
                }

                if(lastName==="")
                {
                    document.getElementById("lname").innerHTML="Enter Lastname";
                    document.getElementById("lname").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("lname").innerHTML="";
                   
                }

                if(email==="")
                {
                    document.getElementById("em").innerHTML="Enter Email";
                    document.getElementById("em").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("em").innerHTML="";
                   
                }

                if(birthDate==="")
                {
                    document.getElementById("bd").innerHTML="Enter Date of Birth";
                    document.getElementById("bd").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("bd").innerHTML="";
                   
                }

                if(mobile==="")
                {
                    document.getElementById("mob").innerHTML="Enter Mobile Number";
                    document.getElementById("mob").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("mob").innerHTML="";
                   
                }

                if(countobirth==="")
                {
                    document.getElementById("cob").innerHTML="This is required field";
                    document.getElementById("cob").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("cob").innerHTML="";
                   
                }

				if(countocitizen==="")
                {
                    document.getElementById("coc").innerHTML="This is required field";
                    document.getElementById("coc").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("coc").innerHTML="";
                   
                }

                if(addl1==="")
                {
                    document.getElementById("address").innerHTML="This is required field";
                    document.getElementById("address").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("address").innerHTML="";
                   
                }

                if(citys==="")
                {
                    document.getElementById("city").innerHTML="Enter City ";
                    document.getElementById("city").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("city").innerHTML="";
                   
                }

                if(countrys==="")
                {
                    document.getElementById("country").innerHTML="Enter Country";
                    document.getElementById("country").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("country").innerHTML="";
                   
                }

                if(zipcodes==="")
                {
                    document.getElementById("zipcode").innerHTML="Enter Zipcode";
                    document.getElementById("zipcode").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("zipcode").innerHTML="";
                   
                }

                if(intakes==="")
                {
                    document.getElementById("intake").innerHTML="Select the term";
                    document.getElementById("intake").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("intake").innerHTML="";
                   
                }


                if(ms_program==="")
                {
                    document.getElementById("program").innerHTML="Enter Program Name";
                    document.getElementById("program").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("program").innerHTML="";
                   
                }


 				if(campuss==="")
                {
                    document.getElementById("campus").innerHTML="Select Campus";
                    document.getElementById("campus").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("campus").innerHTML="";
                   
                }


                
                            

                if(passport==="")
                {
                    document.getElementById("passp").innerHTML="Upload your Passport";
                    document.getElementById("passp").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("passp").innerHTML="";
                   
                }

				if(gres==="")
                {
                    document.getElementById("gre").innerHTML="Upload your Passport GRE scorecard";
                    document.getElementById("gre").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("gre").innerHTML="";
                   
                }

                if(english==="")
                {
                    document.getElementById("ielts").innerHTML="upload your English Proficiency score";
                    document.getElementById("ielts").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("ielts").innerHTML="";
                   
                }

                if(ug_trans==="")
                {
                    document.getElementById("transcript").innerHTML="Upload your UG Transcript";
                    document.getElementById("transcript").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("transcript").innerHTML="";
                   
                }

                if(ug_degree==="")
                {
                    document.getElementById("degree").innerHTML="Upload your UG Degree";
                    document.getElementById("degree").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("degree").innerHTML="";
                   
                }

                if(ug_marksheet==="")
                {
                    document.getElementById("marksheet").innerHTML="Upload your UG Marksheet";
                    document.getElementById("marksheet").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("marksheet").innerHTML="";
                   
                }

				if(lors==="")
                {
                    document.getElementById("lor").innerHTML="Upload your Recommendation Letter combined in one pdf";
                    document.getElementById("lor").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("lor").innerHTML="";
                   
                }

                if(sops==="")
                {
                    document.getElementById("sop").innerHTML="Upload your Statement of Purpose";
                    document.getElementById("sop").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("sop").innerHTML="";
                   
                }

                if(resumes==="")
                {
                    document.getElementById("resume").innerHTML="Upload your Resume";
                    document.getElementById("resume").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("resume").innerHTML="";
                   
                }

				if(ssign==="")
                {
                    document.getElementById("sign").innerHTML="Student Signature is required";
                    document.getElementById("sign").style.color="#a91b4b";
                    return false;
                }
                else
                {
                    document.getElementById("sign").innerHTML="";
                   
                }


                return true;
                
            }