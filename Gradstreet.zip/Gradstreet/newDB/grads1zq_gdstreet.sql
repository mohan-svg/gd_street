-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 23, 2020 at 10:35 AM
-- Server version: 5.6.41-84.1
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grads1zq_gdstreet`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `name`, `password`, `updated_on`) VALUES
(1, 'mohan@gmail.com', 'Mohan', '123456789', '2019-09-25 06:21:44'),
(2, 'kk@gmail.com', 'kamlesh', '123456', '2019-09-18 06:18:18'),
(3, 'jk@gmail.com', 'jaya', '123456', '2019-09-18 06:19:30'),
(4, 'admin@gmail.com', 'Admin', '123456', '2019-09-18 06:23:51'),
(6, 'abc@gmail.com', 'abc', '123456', '2019-09-18 06:42:24'),
(7, 'unknown@gmail.com', 'unknown', '123456', '2019-09-18 11:06:46'),
(8, 'test@gmail.com', 'Test', '123456789', '2019-10-04 09:06:32');

-- --------------------------------------------------------

--
-- Table structure for table `admit_rejects`
--

CREATE TABLE `admit_rejects` (
  `admit_reject_id` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `university_name` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `term` varchar(200) NOT NULL,
  `gre` varchar(20) NOT NULL,
  `eng_test_name` varchar(100) NOT NULL,
  `eng_test_score` varchar(20) NOT NULL,
  `ug_cgpa` varchar(20) NOT NULL,
  `work_exp` int(10) NOT NULL,
  `ar_status` varchar(200) NOT NULL,
  `admit_reject_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admit_rejects`
--

INSERT INTO `admit_rejects` (`admit_reject_id`, `student_name`, `university_name`, `course_name`, `term`, `gre`, `eng_test_name`, `eng_test_score`, `ug_cgpa`, `work_exp`, `ar_status`, `admit_reject_updated`) VALUES
(1, 'Meghana N Pandey', 'Northeastern University', 'Ms Analytics', 'Spring 2020', '306', 'IELTS', '7', '7.5', 25, 'Reject', '2020-02-28 08:50:53'),
(2, 'Ayush Kumar', 'Northeastern University', 'Ms Analytics', 'Spring 2020', 'NA', 'TOEFL', '95', '8.8', 39, 'Admit', '2019-10-21 07:33:33'),
(4, 'Jyotsna Deshmukh', 'Arizona State University', 'Ms Computer Science', 'Fall 2020', '290', 'IELTS', '7.0', '8.0', 12, 'Reject', '2020-02-28 11:34:54'),
(5, 'Jeevan Kumar', 'University Of Texas Dallas', 'Mcs Big Data', 'Fall 2020', '320', 'IELTS', '7.5', '6.8', 15, 'Admit', '2020-02-28 11:34:54'),
(6, 'Harshal Mehta', 'University Of Dayton', 'Ms Construction Management', 'Fall 2019', '305', 'TOEFL', '95', '8.0', 14, 'Admit', '2020-02-28 11:35:31'),
(8, 'Fashgffdsf', 'Fdsadfsaf', 'Fdsafasdf', 'Fsdafasdf', '46544', 'IELTS', '456', 'fdsfasf', 456, 'Applied', '2020-02-28 11:59:10');

-- --------------------------------------------------------

--
-- Table structure for table `benefit`
--

CREATE TABLE `benefit` (
  `b_id` int(11) NOT NULL,
  `b_univ_fees` int(11) NOT NULL,
  `app_fees_free` varchar(250) NOT NULL,
  `b_app_process_fees` int(11) NOT NULL,
  `app_process_free` varchar(10) NOT NULL,
  `university_id` int(11) NOT NULL,
  `b_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `benefit`
--

INSERT INTO `benefit` (`b_id`, `b_univ_fees`, `app_fees_free`, `b_app_process_fees`, `app_process_free`, `university_id`, `b_updated`) VALUES
(3, 80, 'no', 40, 'yes', 5, '2020-03-04 12:54:33'),
(4, 115, 'yes', 60, 'yes', 10, '2020-03-17 12:04:16'),
(5, 70, 'yes', 60, 'yes', 11, '2020-03-17 12:06:45');

-- --------------------------------------------------------

--
-- Table structure for table `course_group`
--

CREATE TABLE `course_group` (
  `course_group_id` int(11) NOT NULL,
  `course_group_name` varchar(255) NOT NULL,
  `course_group_details` text NOT NULL,
  `course_group_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_group`
--

INSERT INTO `course_group` (`course_group_id`, `course_group_name`, `course_group_details`, `course_group_updated`) VALUES
(3, 'MS Aerospace Engineering', 'If you have passion for spacecraft or aircraft, in addition to strong math and physics skills, then a career as an aerospace engineer may be a great fit for you. Aerospace engineers design aircraft, spacecraft, and propulsion systems. It is one of the most challenging fields of engineering and requires special academic qualifications and training. However, if you get the right education and gain experience in the field, you’ll have no problem establishing your career in aerospace engineering.', '2020-04-17 11:21:47'),
(4, 'MS Biomedical Engineering', 'Biomedical engineers develop solutions to health problems through the integration of biology, medicine, and engineering. Your preparation for a career in biomedical engineering should begin in high school. As an undergraduate, you will be required to take courses in engineering, biology, chemistry, math, and physics. Your interdisciplinary education will prepare you to pursue a variety of advanced degrees or equip you to begin your career.', '2020-04-17 11:21:47'),
(5, 'MS Chemical Engineering', 'A career as a chemical engineer is a rewarding path that offers interesting work and very good compensation. In addition, chemical engineering is suitable for a wide range of people with different interests and talents. Becoming a chemical engineer, though, is somewhat challenging, as you must attain the proper educational prerequisites, gain certain experience, and commit yourself to a job search. However, with commitment and perseverance, you’ll be on your way to an exciting career as a chemical engineer.', '2020-04-17 11:21:47'),
(6, 'MS Civil Engineering', 'Civil engineers are responsible for designing and building much of the infrastructure that helps societies function, like roadways, water pipes, and airports. If you want a challenging but rewarding job creating important structures, becoming a civil engineer could be the career of your dreams -- but figuring out where to start can feel like a daunting task. Luckily, wikiHow has done all the research for you! We\'ve got all the most authoritative information here, including advice from The National Council of Examiners for Engineering and Surveying and the U.S. Bureau of Labor Statistics, to make sure you know exactly how to accomplish your goals.\r\n', '2020-04-17 11:23:23'),
(7, 'MS Electrical Engineering', 'Electrical engineering is an engineering discipline concerned with the study, design and application of equipment, devices and systems which use electricity, electronics, and electromagnetism.Electrical engineering is now divided into a wide range of fields including, computer engineering, power engineering, telecommunications, radio-frequency engineering, signal processing, instrumentation, and electronics. Many of these disciplines overlap with other engineering branches, spanning a huge number of specializations including hardware engineering, power electronics, electromagnetics and waves, microwave engineering, nanotechnology, electrochemistry, renewable energies, mechatronics, and electrical materials science. See glossary of electrical and electronics engineering.', '2020-04-17 11:23:23'),
(8, 'MS Computer Science', 'Computer science is the study of processes that interact with data and that can be represented as data in the form of programs. It enables the use of algorithms to manipulate, store, and communicate digital information. A computer scientist studies the theory of computation and the design of software systems.These days, understanding how to use a computer is helpful in many areas of life, from work to school to socializing. Computer science is a field of study that takes computing to the next level, understanding not just how to use the computer but how the computer itself works, and how to make it do new things efficiently. More and more people are learning computer science and turning their knowledge into a lucrative career in fields like business, health care, engineering, and many others.', '2020-04-17 11:23:23'),
(9, 'MS Environmental Engineering', 'MS Environmental Engineering', '2020-04-17 11:23:23'),
(10, 'MS Mechanical Engineering', 'MS Mechanical Engineering', '2020-04-17 11:23:23'),
(11, 'MS Exercise Science', 'MS Exercise Science', '2020-04-17 11:23:23'),
(12, 'MS Biotechnology', 'MS Biotechnology', '2020-04-17 11:23:23'),
(13, 'MS Human Computer Interaction', 'MS Human Computer Interaction', '2020-04-17 11:23:23'),
(14, 'MS Information Technology', 'MS Information Technology', '2020-04-17 11:25:18'),
(15, 'MS Telecommunication', 'MS Telecommunication', '2020-04-17 11:25:18'),
(16, 'MS Food & Nutrition', 'MS Food & Nutrition', '2020-04-17 11:25:18'),
(17, 'MS Journalism', 'MS Journalism', '2020-04-17 11:25:18'),
(18, 'MS Music', 'MS Music', '2020-04-17 11:25:18'),
(19, 'MS Data Science', 'MS Data Science', '2020-04-17 11:29:25'),
(20, 'MS Business Analytics', 'MS Business Analytics', '2020-04-17 11:29:25'),
(21, 'MS Analytics', 'MS Analytics', '2020-04-17 11:29:25'),
(22, 'MS Informatics', 'MS Informatics', '2020-04-17 11:29:25'),
(23, 'MS Cellular and Molecular Biology', 'MS Cellular and Molecular Biology', '2020-04-17 11:29:25'),
(24, 'MS Engineering Management', 'MS Engineering Management', '2020-04-17 11:29:25'),
(25, 'MS Industrial Engineering', 'MS Industrial Engineering', '2020-04-17 11:29:25'),
(26, 'MS Construction Management', 'MS Construction Management', '2020-04-17 11:29:25'),
(27, 'MS Manufacturing Engineering', 'MS Manufacturing Engineering', '2020-04-17 11:29:25'),
(28, 'MS Material Engineering', 'MS Material Engineering', '2020-04-17 11:29:25'),
(29, 'MS International Business', 'MS International Business', '2020-04-17 11:29:25'),
(30, 'Master of Law (LLM)', 'Master of Law (LLM)', '2020-04-17 11:29:25'),
(31, 'MS Taxation', 'MS Taxation', '2020-04-17 11:29:25'),
(32, 'MS Sports and Entertainment', 'MS Sports and Entertainment', '2020-04-17 11:29:25'),
(33, 'Master in Arts', 'Master in Arts', '2020-04-17 11:29:25'),
(34, 'MA/ MS History', 'MA/ MS History', '2020-04-17 11:29:25'),
(35, 'MS Accounting', 'MS Accounting', '2020-04-17 11:29:25'),
(36, 'MBA / Business Administration', 'MBA / Business Administration', '2020-04-17 11:29:25'),
(37, 'MS Economics', 'MS Economics', '2020-04-17 11:29:25'),
(38, 'MS Finance', 'MS Finance', '2020-04-17 11:29:25'),
(39, 'MS Health Management', 'MS Health Management', '2020-04-17 11:29:25'),
(40, 'MS TESOL', 'MS TESOL', '2020-04-17 11:29:25'),
(41, 'MS Statistics', 'MS Statistics', '2020-04-17 11:29:25'),
(42, 'MS Chemistry', 'MS Chemistry', '2020-04-17 11:32:35'),
(43, 'MS Geology and Geological Engineering', 'MS Geology and Geological Engineering', '2020-04-17 11:32:35'),
(44, 'MS Mathematics', 'MS Mathematics\r\n', '2020-04-17 11:32:35'),
(45, 'MS Philosophy', 'MS Philosophy\r\n', '2020-04-17 11:32:35'),
(46, 'MS Political Science', 'MS Political Science\r\n', '2020-04-17 11:32:35'),
(47, 'MS/MA Criminal Justice', 'MS/MA Criminal Justice\r\n', '2020-04-17 11:32:35'),
(48, 'MS Forensic Science', 'MS Forensic Science\r\n', '2020-04-17 11:32:35'),
(49, 'MS Psychology', 'MS Psychology\r\n', '2020-04-17 11:32:35'),
(50, 'MS Social Media & Marketing', 'MS Social Media & Marketing\r\n', '2020-04-17 11:32:35'),
(51, 'MS Human Resource Management', 'MS Human Resource Management\r\n', '2020-04-17 11:32:35'),
(52, 'MS Management', 'MS Management\r\n', '2020-04-17 11:32:35'),
(53, 'MS Leadership', 'MS Leadership\r\n', '2020-04-17 11:32:35'),
(54, 'MS Digital Media', 'MS Digital Media\r\n', '2020-04-17 11:32:35'),
(55, 'MS Internet and Cyber Security', 'MS Internet and Cyber Security\r\n', '2020-04-17 11:32:35'),
(56, 'MA Communication', 'MA Communication\r\n', '2020-04-17 11:32:35'),
(57, 'MA Text & Literature', 'MA Text & Literature', '2020-04-17 11:32:35'),
(58, 'MS Hospital Management', 'MS Hospital Management\r\n', '2020-04-17 11:32:35');

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `faqs_id` int(11) NOT NULL,
  `questions` varchar(255) NOT NULL,
  `answers` text NOT NULL,
  `faq_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `news_id` int(11) NOT NULL,
  `news_title` varchar(250) NOT NULL,
  `content` longtext NOT NULL,
  `news_image` varchar(250) NOT NULL,
  `posting_date` varchar(250) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_title`, `content`, `news_image`, `posting_date`, `updated`) VALUES
(1, 'A Breaking New - SUNY Paltz', 'fdsfhasdjkfhlkjnd kjsafhndjksfhnasjkd dkj hfsajdkf djsh aksdfasfds', '13169572723_486cc05a65_b.jpg', '2019-09-22', '2019-09-21 07:58:56'),
(2, 'Number of ultra rich falls to 2.56 lakh in 2018 from 2.63 lakh', 'Bibendum enim facilisis gravida neque convallis a. Enim sit amet venenatis urna cursus eget. Donec enim diam vulputate ut pharetra sit amet. Auctor augue mauris augue neque gravida in. Sed felis eget velit aliquet sagittis id consectetur purus. Et netus et malesuada fames ac turpis. Tempus quam pellentesque nec nam aliquam. Faucibus pulvinar elementum integer enim neque. In hac habitasse platea dictumst quisque. Mattis aliquam faucibus purus in massa tempor nec. Tincidunt tortor aliquam nulla facilisi cras fermentum. Lectus proin nibh nisl condimentum id venenatis a. Magna fermentum iaculis eu non diam phasellus vestibulum. Odio tempor orci dapibus ultrices in. Nullam eget felis eget nunc lobortis mattis aliquam. Urna et pharetra pharetra massa massa ultricies. Luctus accumsan tortor posuere ac ut consequat semper viverra nam. Consectetur adipiscing elit ut aliquam purus sit. Eu scelerisque felis imperdiet proin.', 'dayton_university_-3.jpg', '2019-10-15', '2019-10-17 10:56:59'),
(3, 'IL&FS completes sale of wind energy assets to Orix', 'Risus commodo viverra maecenas accumsan lacus vel. Scelerisque viverra mauris in aliquam sem fringilla ut morbi. Ac turpis egestas maecenas pharetra convallis posuere morbi leo. Vitae ultricies leo integer malesuada nunc. Dignissim suspendisse in est ante in. Cras ornare arcu dui vivamus arcu felis bibendum ut tristique. Morbi tincidunt ornare massa eget egestas. Est pellentesque elit ullamcorper dignissim cras. In fermentum posuere urna nec. Mi proin sed libero enim sed faucibus turpis in. Accumsan sit amet nulla facilisi morbi. Gravida arcu ac tortor dignissim convallis aenean. Tellus mauris a diam maecenas sed enim ut. Risus feugiat in ante metus dictum at. Iaculis nunc sed augue lacus. Placerat duis ultricies lacus sed turpis tincidunt id. Sapien et ligula ullamcorper malesuada proin libero nunc consequat. Dui id ornare arcu odio.', 'campus.jpg', '2019-10-17', '2019-10-17 10:58:54'),
(4, 'Netherlands can help India become the food factory of the world: Dutch Minister', 'Tellus mauris a diam maecenas sed. Pharetra convallis posuere morbi leo. Luctus accumsan tortor posuere ac ut consequat. Lacus sed viverra tellus in hac habitasse platea. Tortor posuere ac ut consequat semper. Elit ut aliquam purus sit amet luctus. Vitae ultricies leo integer malesuada nunc vel risus commodo. Pellentesque habitant morbi tristique senectus. Sed euismod nisi porta lorem mollis aliquam ut porttitor leo. Eget egestas purus viverra accumsan in nisl. Dignissim convallis aenean et tortor at risus. Fusce ut placerat orci nulla pellentesque dignissim enim sit. Bibendum neque egestas congue quisque egestas diam in arcu cursus. Cursus euismod quis viverra nibh cras pulvinar mattis nunc. Dolor sit amet consectetur adipiscing elit pellentesque. Non enim praesent elementum facilisis leo vel fringilla est. Enim lobortis scelerisque fermentum dui faucibus in. Sapien faucibus et molestie ac feugiat sed lectus vestibulum mattis. Tincidunt augue interdum velit euismod in. Mus mauris vitae ultricies leo.', 'dayton_university.jpg', '2019-10-18', '2019-10-17 11:01:36'),
(5, 'SC refuses to entertain plea seeking relief from RBI\'s money withdrawal limit for PMC bank depositors', 'The plea had sought directions to protect the interests of around 15 lakh customers whose money is blocked in the Punjab and Maharashtra Co-operative Bank scam. The RBI had put the initial cap on withdrawal at Rs. 1,000 and later increased to Rs. 40,000.Finance Minister gave a clarion call for concerted action in the face of global slowdown and highlighted that emerging market economies in particular face the challenge of achieving economic growth and inclusive development.', 'o-SYRACUSE-UNIVERSITY-facebook.jpg', '2019-10-18', '2019-10-18 08:26:25');

-- --------------------------------------------------------

--
-- Table structure for table `score_reporting`
--

CREATE TABLE `score_reporting` (
  `score_reporting_id` int(11) NOT NULL,
  `gre_code` int(11) NOT NULL,
  `toefl_code` int(11) NOT NULL,
  `university_id` int(11) NOT NULL,
  `score_repoting_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `stud_id` int(11) NOT NULL,
  `stud_fname` varchar(250) NOT NULL,
  `stud_lname` varchar(250) NOT NULL,
  `stud_mail_address` varchar(250) NOT NULL,
  `city` varchar(100) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `mobile1` varchar(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `gre` varchar(150) NOT NULL,
  `gre_total` int(11) NOT NULL,
  `gre_quants` int(11) NOT NULL,
  `gre_verbal` int(11) NOT NULL,
  `ielts_toefl` varchar(150) NOT NULL,
  `ielts_toefl_score` int(11) NOT NULL,
  `ug_college` varchar(250) NOT NULL,
  `ug_course` varchar(250) NOT NULL,
  `ug_gpa` varchar(50) NOT NULL,
  `ug_passing_year` varchar(250) NOT NULL,
  `pg_appeared` varchar(250) NOT NULL,
  `pg_college` varchar(250) NOT NULL,
  `pg_course` varchar(250) NOT NULL,
  `pg_gpa` varchar(20) NOT NULL,
  `pg_passing_year` varchar(250) NOT NULL,
  `work_exp` varchar(250) NOT NULL,
  `work_duration` varchar(250) NOT NULL,
  `work_org` varchar(250) NOT NULL,
  `stud_position` varchar(250) NOT NULL,
  `in_process_university` text NOT NULL,
  `submited_university` text NOT NULL,
  `login_id` int(11) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`stud_id`, `stud_fname`, `stud_lname`, `stud_mail_address`, `city`, `zipcode`, `mobile1`, `email`, `gender`, `gre`, `gre_total`, `gre_quants`, `gre_verbal`, `ielts_toefl`, `ielts_toefl_score`, `ug_college`, `ug_course`, `ug_gpa`, `ug_passing_year`, `pg_appeared`, `pg_college`, `pg_course`, `pg_gpa`, `pg_passing_year`, `work_exp`, `work_duration`, `work_org`, `stud_position`, `in_process_university`, `submited_university`, `login_id`, `updated`) VALUES
(1, 'Mohan', 'Pal', 'dfgashjfgdjhfghsdajfdsaff', 'fdsafasdf', 'dsfasdfsa', '9874563211', 'mohan@gmail.com', 'male', 'yes', 320, 160, 160, 'yes', 8, 'TGP', 'gfsaf', '7.8/10', '2018', 'no', '', '', '', '', 'no', '', '', '', '3', '3,3,3,2,3,3,2,2,2,2,2,2,2,2', 1318843, '2019-10-17 11:24:13'),
(2, 'Mohfhsdaff', 'dsafasd', 'fsdaf', 'fdsfas', 'fsdaf', 'fsdafasd', 'abc@gmail.com', 'male', 'no', 0, 0, 0, 'no', 0, 'fdsaf', 'dfsafa', '4654', '456', 'no', '', '', '', '', 'no', '', '', '', '', '', 2578250, '2019-09-23 08:38:51'),
(3, 'Rohan', 'Gavaskar', 'Haryana bazar, Chota Bheem, Bus Stop', 'Haryana', '123456', '1234567894', 'mohan@yahoo.com', 'male', 'yes', 300, 150, 150, 'yes', 110, 'My College', 'My Course', '10/10', '2015', 'yes', 'My PG College', 'My PG Course', '9.0/10', '2018', 'yes', '05/2018-09/2019', 'Not My Company', 'My Designation', '', '', 6550682, '2019-09-23 11:35:08'),
(4, 'Jagga', 'Jasoos', 'fsdfsaf454', 'fdsafas', '456465', '1234567894', 'jagga@gmail.com', 'male', 'yes', 320, 160, 160, 'no', 0, 'fdsafas', 'fsadfsa', '5464', '456', 'no', '', '', '', '', 'no', '', '', '', '3', '', 6695038, '2019-09-23 11:53:56'),
(5, 'ABCD', 'ABCS', 'fdfsdafsdf45fds', 'fdsfdsf', '456454', '4564564564', 'abcd@gmail.com', 'male', 'no', 0, 0, 0, 'no', 0, 'fdsfsdaf', 'fdsfsa', '45645', '1212', 'no', '', '', '', '', 'no', '', '', '', '3', '2,3,3,3,3', 9818432, '2019-09-24 11:54:52');

-- --------------------------------------------------------

--
-- Table structure for table `stud_login`
--

CREATE TABLE `stud_login` (
  `login_id` int(11) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_login`
--

INSERT INTO `stud_login` (`login_id`, `email`, `password`, `updated`) VALUES
(1318843, 'mohan@gmail.com', '123456789', '2019-09-24 08:25:21'),
(2578250, 'abc@gmail.com', '123456', '2019-09-23 08:38:51'),
(6550682, 'mohan@yahoo.com', '123456', '2019-09-23 11:35:08'),
(6695038, 'jagga@gmail.com', '123456789', '2019-09-23 11:46:56'),
(9818432, 'abcd@gmail.com', 'mohan555', '2019-09-24 10:33:45');

-- --------------------------------------------------------

--
-- Table structure for table `submitted_applications`
--

CREATE TABLE `submitted_applications` (
  `app_id` int(11) NOT NULL,
  `stud_id` int(11) NOT NULL,
  `university_id` int(11) NOT NULL,
  `university_name` varchar(250) NOT NULL,
  `degree` varchar(250) NOT NULL,
  `course_1` varchar(250) NOT NULL,
  `specialization_1` varchar(250) NOT NULL,
  `course_2` varchar(250) NOT NULL,
  `specialization_2` varchar(250) NOT NULL,
  `term` varchar(250) NOT NULL,
  `app_status` varchar(250) NOT NULL,
  `decision` varchar(250) NOT NULL,
  `submitted_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `university_details`
--

CREATE TABLE `university_details` (
  `university_details_id` int(11) NOT NULL,
  `university_name_id` int(11) NOT NULL,
  `course_group_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `entry_terms` varchar(255) NOT NULL,
  `deadline` varchar(255) NOT NULL,
  `gre_total` float NOT NULL,
  `gre_quants` float NOT NULL,
  `gre_verbal` float NOT NULL,
  `ielts` float NOT NULL,
  `ielts_subscores` float NOT NULL,
  `toefl` float NOT NULL,
  `toefl_subscore` float NOT NULL,
  `gmat_total` int(11) NOT NULL,
  `gpa` varchar(100) NOT NULL,
  `work_exp` varchar(255) NOT NULL,
  `fees` varchar(200) NOT NULL,
  `university_details_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `university_details`
--

INSERT INTO `university_details` (`university_details_id`, `university_name_id`, `course_group_id`, `course_name`, `entry_terms`, `deadline`, `gre_total`, `gre_quants`, `gre_verbal`, `ielts`, `ielts_subscores`, `toefl`, `toefl_subscore`, `gmat_total`, `gpa`, `work_exp`, `fees`, `university_details_updated`) VALUES
(6, 10, 3, 'MS Aerospace Engineering', 'Fall,Spring', 'Fall - 01 August , Spring 01 December', 305, 159, 146, 6.5, 6.5, 80, 20, 0, '3.0/4.0', 'Optional', '', '2020-04-17 13:44:18'),
(7, 10, 4, 'MS Biomedical Engineering', 'Fall,Spring', 'Fall - 01 August , Spring 01 December', 295, 145, 150, 6.5, 6.5, 80, 20, 0, '3.0/4.0', 'Optional', '', '2020-04-17 14:11:47');

-- --------------------------------------------------------

--
-- Table structure for table `university_name`
--

CREATE TABLE `university_name` (
  `u_name_id` int(11) NOT NULL,
  `university_name` varchar(255) NOT NULL,
  `campus` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `tuition_fees` varchar(200) NOT NULL DEFAULT '0',
  `ranking` int(11) NOT NULL,
  `u_name_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `university_name`
--

INSERT INTO `university_name` (`u_name_id`, `university_name`, `campus`, `location`, `description`, `tuition_fees`, `ranking`, `u_name_updated`) VALUES
(10, 'Arizona State University', 'Tempe Campus,  Downtown Phoenix Campus,  Polytechnic Campus,  West Campus ', 'Tempe, Arizona, United States', 'Since 2005, ASU has been ranked among the top research universities in the U.S., public and private, based on research output, innovation, development, research expenditures, number of awarded patents and awarded research grant proposals. The 2019 university ratings by U.S. News & World Report rank ASU No. 1 among the Most Innovative Schools in America for the fourth year in a row. Arizona State University (commonly referred to as ASU or Arizona State) is a public metropolitan research university on five campuses across the Phoenix metropolitan area and four regional learning centers throughout Arizona. ASU is one of the largest public universities by enrollment in the U.S As of fall 2019, the university had nearly 90,000 students attending classes across its metro campuses \r\n', 'USD 31,400 per year', 0, '2020-04-18 10:12:25'),
(11, 'University Of Illinois At Chicago', 'Chicago Campus', 'Chicago, Illinois, United States', 'Located in the heart of one of the world’s great cities, the University of Illinois at Chicago is a vital part of the educational, technological and cultural fabric of the region. As Chicago’s only public research university with more than 33,000 students, 16 colleges, a hospital and a health sciences system, UIC provides students access to excellence and opportunity. As Chicago’s only public research university, real-world problems are solved through innovation and discovery. Research at the University of Illinois at Chicago is re-shaping educational policy; developing cleaner, more sustainable energy; helping to make sense of today’s vast amounts of computer-generated data; and driving economic development by moving research to practical application. Outstanding programs range from the creation of new medical diagnostic techniques to turning carbon dioxide into fuel. You will find opportunities to pursue your interests in depth with researchers on the cutting edge of discovery in the humanities, social sciences, natural and medical sciences and engineering.\r\n', '$28,000 per Year', 0, '2020-04-18 10:12:36');

-- --------------------------------------------------------

--
-- Table structure for table `univ_image`
--

CREATE TABLE `univ_image` (
  `u_image_id` int(11) NOT NULL,
  `main_img` varchar(250) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `img1` varchar(250) NOT NULL,
  `img2` varchar(250) NOT NULL,
  `img3` varchar(250) NOT NULL,
  `img4` varchar(250) NOT NULL,
  `img5` varchar(250) NOT NULL,
  `university_id` int(11) NOT NULL,
  `i_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `univ_image`
--

INSERT INTO `univ_image` (`u_image_id`, `main_img`, `logo`, `img1`, `img2`, `img3`, `img4`, `img5`, `university_id`, `i_updated`) VALUES
(4, 'campus-downtown.jpg', 'asu_university_horiz_rgb_maroongold_600.png', 'campus-tempe.jpg', 'campus1.jpg', 'asu-technology-concussion-science.jpg', 'slider_image.jpg', 'st-marys-church-asu-1.jpg', 10, '2020-04-17 13:22:46'),
(5, 'university-illinois-chicago-8.jpg', 'UIC-Logo.png', 'DJI_0080.jpg', 'DSC_1187.jpg', 'UniversityofIllinoisChicago.jpg', 'UIC_Campus.jpg', 'UIC-1090x595.jpg', 11, '2020-04-17 13:24:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admit_rejects`
--
ALTER TABLE `admit_rejects`
  ADD PRIMARY KEY (`admit_reject_id`);

--
-- Indexes for table `benefit`
--
ALTER TABLE `benefit`
  ADD PRIMARY KEY (`b_id`),
  ADD UNIQUE KEY `university_id` (`university_id`),
  ADD UNIQUE KEY `university_id_2` (`university_id`),
  ADD UNIQUE KEY `university_id_3` (`university_id`);

--
-- Indexes for table `course_group`
--
ALTER TABLE `course_group`
  ADD PRIMARY KEY (`course_group_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`faqs_id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Indexes for table `score_reporting`
--
ALTER TABLE `score_reporting`
  ADD PRIMARY KEY (`score_reporting_id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `stud_login`
--
ALTER TABLE `stud_login`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `submitted_applications`
--
ALTER TABLE `submitted_applications`
  ADD PRIMARY KEY (`app_id`);

--
-- Indexes for table `university_details`
--
ALTER TABLE `university_details`
  ADD PRIMARY KEY (`university_details_id`);

--
-- Indexes for table `university_name`
--
ALTER TABLE `university_name`
  ADD PRIMARY KEY (`u_name_id`),
  ADD UNIQUE KEY `university_name` (`university_name`);

--
-- Indexes for table `univ_image`
--
ALTER TABLE `univ_image`
  ADD PRIMARY KEY (`u_image_id`),
  ADD UNIQUE KEY `university_id` (`university_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `admit_rejects`
--
ALTER TABLE `admit_rejects`
  MODIFY `admit_reject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `benefit`
--
ALTER TABLE `benefit`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `course_group`
--
ALTER TABLE `course_group`
  MODIFY `course_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `faqs_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `score_reporting`
--
ALTER TABLE `score_reporting`
  MODIFY `score_reporting_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `stud_login`
--
ALTER TABLE `stud_login`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9818433;

--
-- AUTO_INCREMENT for table `submitted_applications`
--
ALTER TABLE `submitted_applications`
  MODIFY `app_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `university_details`
--
ALTER TABLE `university_details`
  MODIFY `university_details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `university_name`
--
ALTER TABLE `university_name`
  MODIFY `u_name_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `univ_image`
--
ALTER TABLE `univ_image`
  MODIFY `u_image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
